#ifndef NODE_H
#define NODE_H

class node_t {
    public:
    int value;
    int height;
    node_t* right;
    node_t* left;
};

#endif //NODE_H