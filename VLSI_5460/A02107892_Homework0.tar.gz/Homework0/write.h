#ifndef WRITE_H
#define WRITE_H

#include <string>

void write(std::string text);

#endif //WRITE_H