Calvin Passmore

A02107892

10/18/22

# Homework 3_3 Programming

To compile the program

    $ make

To compile and run the program

    $ make run